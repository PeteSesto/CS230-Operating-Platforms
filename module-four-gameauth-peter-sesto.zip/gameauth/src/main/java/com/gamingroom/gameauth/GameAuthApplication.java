package com.gamingroom.gameauth;

import com.gamingroom.gameauth.auth.GameAuthenticator;
import com.gamingroom.gameauth.auth.GameAuthorizer;
import com.gamingroom.gameauth.auth.GameUser;
import com.gamingroom.gameauth.controller.GameUserRESTController;
import com.gamingroom.gameauth.healthcheck.AppHealthCheck;
import com.gamingroom.gameauth.healthcheck.HealthCheckController;
import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Client;


public class GameAuthApplication extends Application<Configuration> {
    private static final Logger LOGGER = LoggerFactory.getLogger(GameAuthApplication.class);

    @Override
    public void initialize(Bootstrap<Configuration> b) {
    }

    @Override
    public void run(Configuration c, Environment e) throws Exception {

        LOGGER.info("Registering REST resources");

        // Register the GameUserRESTController to expose the /gameusers API endpoints.
        // This passes the environment validator to ensure data integrity.
        e.jersey().register(new GameUserRESTController(e.getValidator()));

        // Create a Jersey Client instance named "DemoRESTClient".
        // This client allows the application to act as a consumer of other REST APIs.
        final Client client = new JerseyClientBuilder(e).build("DemoRESTClient");

        // Application health check
        e.healthChecks().register("APIHealthCheck", new AppHealthCheck(client));

        // Run multiple health checks
        e.jersey().register(new HealthCheckController(e.healthChecks()));

        //Setup Basic Security
        e.jersey().register(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<GameUser>()
                .setAuthenticator(new GameAuthenticator())
                .setAuthorizer(new GameAuthorizer())
                .setRealm("App Security")
                .buildAuthFilter()));
        e.jersey().register(new AuthValueFactoryProvider.Binder<>(GameUser.class));
        e.jersey().register(RolesAllowedDynamicFeature.class);
    }

    public static void main(String[] args) throws Exception {
        new GameAuthApplication().run(args);
    }
}