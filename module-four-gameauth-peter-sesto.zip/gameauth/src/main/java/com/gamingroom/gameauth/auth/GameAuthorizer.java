package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

import java.util.Set;

public class GameAuthorizer implements Authorizer<GameUser> {
    @Override
    public boolean authorize(GameUser user, String role) {

        // Check if the user has any roles assigned and if those roles include the required permission.
        // Returns true if the user is authorized for the requested resource.
        Set<String> roles = user.getRoles();
        return roles != null && roles.contains(role);
    }
}