package com.gamingroom.gameauth.auth;


import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
            "guest", ImmutableSet.of(),
            "user", ImmutableSet.of("USER"),
            "admin", ImmutableSet.of("ADMIN", "USER")
    );

    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {

        // Validate the username against the known list and ensure the password matches.
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) {

            // If credentials are valid, create and return a new GameUser with the associated roles.
            // This establishes the user's identity (Principal) for the security context.
            return Optional.of(
                    new GameUser(
                            credentials.getUsername(),
                            VALID_USERS.get(credentials.getUsername())
                    )
            );
        }
        return Optional.empty();
    }
}
