package com.gamingroom.gameauth.controller;

import com.gamingroom.gameauth.representations.GameUserInfo;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;

@Produces(MediaType.TEXT_PLAIN)
@Path("/client/")
public class RESTClientController {
    private Client client;

    public RESTClientController(Client client) {
        this.client = client;
    }

    // Expose this method as a GET request at the path "/gameusers".
    // This acts as a client-side proxy to fetch and return the list of all game users.
    @GET
    @Path("/gameusers")
    public String getGameUsers() {
        //Do not hard code in your application
        WebTarget webTarget = client.target("http://localhost:8080/gameusers");
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        @SuppressWarnings("rawtypes")
        ArrayList gameusers = response.readEntity(ArrayList.class);
        return gameusers.toString();
    }

    @GET
    @Path("/gameusers/{id}")
    public String getGameUserById(@PathParam("id") int id) {
        //Do not hard code in your application
        WebTarget webTarget = client.target("http://localhost:8080/gameusers/" + id);
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        GameUserInfo gameUserInfo = response.readEntity(GameUserInfo.class);
        return gameUserInfo.toString();
    }
}