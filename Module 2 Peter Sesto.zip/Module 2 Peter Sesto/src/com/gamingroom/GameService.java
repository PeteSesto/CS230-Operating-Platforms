package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 *
 * @author coce@snhu.edu
 */
public class GameService {

    /**
     * The single instance of GameService (singleton pattern)
     * 'Static' ensures it belongs to the class, not individual objects
     */
    private static GameService instance = null;

    /**
     * A list of the active games
     */
    private static final List<Game> games = new ArrayList<>();

    /*
     * Holds the next game identifier
     */
    private static long nextGameId = 1;

    /**
     * Private constructor to prevent instantiation from outside the class.
     * This is a required component of the singleton pattern. By making the constructor
     * private, we ensure that no other class can create instances using 'new GameService()'.
     */
    private GameService() {
    }

    /**
     * Public static method to get the single instance of GameService.
     * This is the only way to access the GameService instance.
     * Uses lazy initialization. The instance is not created until first called.
     * -------------------------------------------------------------------------
     * Purpose: ensure that only one instance of the GameService exists in memory
     * Characteristics:
     * 1. Private Constructor: Prevents external instantiation.
     * 2. Static Instance Variable: Holds the single instance.
     * 3. Public Static Method (getInstance): Provides global access to that instance.
     * -------------------------------------------------------------------------
     * * @return the single instance of GameService
     */
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    /**
     * Construct a new game instance
     * -------------------------------------------------------------------------
     * Purpose: loop through the collection of active games sequentially without
     * exposing the underlying list implementation to the client.
     * Standardizes how we check for duplicates or find items.
     * Characteristics:
     * 1. Decoupling: Separates looping logic from data implementation.
     * 2. Standard Interface: Uses Java's built-in Iterator interface (hasNext(), next()).
     * 3. Sequential Access: Linearly checks every game instance.
     * -------------------------------------------------------------------------
     * * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {

        // a local game instance
        Game game = getGame(name);

        // if not found, make a new game instance and add to list of games
        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        // return the new/existing game instance to the caller
        return game;
    }

    /**
     * Returns the game instance at the specified index.
     * <p>
     * Scope is package/local for testing purposes.
     * </p>
     *
     * @param index index position in the list to return
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     *
     * @param id unique identifier of game to search for
     * @return requested game instance
     */
    /*
     * TODO: This is currently unused.
     *  Leaving it here in case we build on it in the future.
     *  Should be removed before final code submission if still unused
     */
    public Game getGame(long id) {

        // a local game instance
        Game game = null;

        // Use Iterator to look for existing game with same id
        Iterator<Game> gamesIterator = games.iterator();

        while (gamesIterator.hasNext()) {
            Game gameInstance = gamesIterator.next();

            // Check if a game with this id already exists
            if (gameInstance.getId() == id) {
                // Found existing game, assign it and break
                game = gameInstance;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     *
     * @param name unique name of game to search for
     * @return requested game instance
     */
    public Game getGame(String name) {

        // a local game instance
        Game game = null;

        // Use Iterator to look for existing game with same name
        Iterator<Game> gamesIterator = games.iterator();

        while (gamesIterator.hasNext()) {
            Game gameInstance = gamesIterator.next();

            // Check if a game with this name already exists
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                // Found existing game, assign it and break
                game = gameInstance;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the number of games currently active
     *
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }
}